﻿var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var routes = require('./routes/index');
var users = require('./routes/users');
//
var engine = require('ejs-mate');
//
var app = express();

// view engine setup
// use ejs-locals for all ejs templates:
app.engine('ejs', engine);

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs'); // so you can render('index')



// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(require('stylus').middleware(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));

//app.use('/', routes);
//app.use('/users', users);
//===============================
// render 'index' into 'boilerplate':
app.get('/', function (req, res, next) {
    res.render('default-body', { what: 'best', who: 'me' });
});
app.get('/index', function (req, res, next) {
    res.render('index-body', { what: 'best', who: 'me' });
});
app.get('/block', function (req, res, next) {
    res.render('block-body', { what: 'best', who: 'me' });
});
app.get('/include', function (req, res, next) {
    res.render('include-body', { what: 'best', who: 'me', muppets: ['Kermit', 'Fozzie', 'Gonzo'] });
    //res.render('include-body', { what: 'best', who: 'me' });
});
app.get('/partial', function (req, res, next) {
    res.render('partial-body', { what: 'best', who: 'me', muppets: ['Kermit', 'Fozzie', 'Gonzo'] });
});

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers

// development error handler
// will print stacktrace
//if (app.get('env') === 'development') {
//    app.use(function (err, req, res, next) {
//        res.status(err.status || 500);
//        res.render('error', {
//            message: err.message,
//            error: err
//        });
//    });
//}

// 错误--调试--捕获全局的错误信息
app.use(function (err, req, res, next) {
    var meta = '[' + new Date() + '] ' + req.url + '\n';
    console.log(meta + err.stack + '\n');
    next();
});
// production error handler
// no stacktraces leaked to user
//app.use(function (err, req, res, next) {
//    res.status(err.status || 500);
//    res.render('error', {
//        message: err.message,
//        error: {}
//    });
//});


module.exports = app;
