﻿
/**
 * Module dependencies.
 */

var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');

//var bodyParser = require('body-parser');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();


var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(app.router);
app.use(require('stylus').middleware(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));
//
//app.use(bodyParser.json({ limit: '1mb' }));  //这里指定参数使用 json 格式
//app.use(bodyParser.urlencoded({
//    extended: true
//}));

// development only
if ('development' == app.get('env')) {
    app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/users', user.list);
//---
app.post('/urlencoded', function (req, res) {
    console.log(req.body);
    res.send(req.body);

});
//---
app.post('/formdata', multipartMiddleware, function (req, res) {
    console.log(req.body);
    res.send(req.body);
});
//---/devices/1
app.get('/devices/:id', function (req, res) { //Restful Get方法,查找一个单一资源

    console.log(req.param('id'));
    res.send(req.param());

});
//---/json?id=1&t=1
app.get('/json', function (req, res) {
    console.log(req.query);
    console.log(req.query.id);
    res.send(req.query);

});
app.post('/json', function (req, res) {
    console.log(req.body);
    res.send(req.body);

});
//---/可以接收任何数据
//---如何让 Node-express 支持 XML 形式的 POST 请求
//---http://www.tfan.org/using-xml2js-for-express-body-parser/
app.post('/xml', function (req, res, next) {
    if (req._body) return next();
    req.body = req.body || {};
    var buf = '';
    req.setEncoding('utf8');
    req.on('data', function (chunk) { buf += chunk });
    req.on('end', function () {
        res.send(buf);
        console.log(buf);
    });

});

http.createServer(app).listen(app.get('port'), function () {
    console.log('Express server listening on port ' + app.get('port'));
});
